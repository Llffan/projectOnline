const p="/jpg/BVI-Cg5FJztI.jpg";export{p as _};
