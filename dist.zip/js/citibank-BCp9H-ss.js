const p="/jpg/citibank-C5AIWuRd.jpg";export{p as _};
