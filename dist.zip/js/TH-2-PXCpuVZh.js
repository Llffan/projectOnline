const p="/jpg/TH-ConWDteQ.jpg",o="/jpg/TH-2-BX3Axrb5.jpg";export{p as _,o as a};
