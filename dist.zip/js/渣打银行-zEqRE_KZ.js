const p="/png/%E6%B8%A3%E6%89%93%E9%93%B6%E8%A1%8C-CD9M31cv.png";export{p as _};
