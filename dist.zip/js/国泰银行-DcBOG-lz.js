const B="/png/%E5%9B%BD%E6%B3%B0%E9%93%B6%E8%A1%8C-C7408OAx.png";export{B as _};
