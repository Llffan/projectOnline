const p="/jpg/MY-D4Pvkx44.jpg",s="/jpg/MY-2-By7y6NKH.jpg";export{p as _,s as a};
