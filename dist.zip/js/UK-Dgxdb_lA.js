const o="/jpg/UK-B8oaviAF.jpg";export{o as _};
