const E="/png/%E5%A4%A7%E8%A5%BF%E6%B4%8B%E9%93%B6%E8%A1%8C-BEOP_QID.png";export{E as _};
