const p="/jpg/1-Djk5i2Ko.jpg",o="/jpg/2-DoC912Dk.jpg",s="/jpg/3-BH6Fym1S.jpg",j="/jpg/4-BVYroAuE.jpg";export{p as _,o as a,s as b,j as c};
