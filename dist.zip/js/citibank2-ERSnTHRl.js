const p="/jpg/citibank2--0RpOZEI.jpg";export{p as _};
