const p="/jpg/dah_sing-Bjt4f4Lm.jpg";export{p as _};
