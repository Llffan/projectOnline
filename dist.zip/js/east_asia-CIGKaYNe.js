const s="/jpg/east_asia-BFNFZT1w.jpg";export{s as _};
