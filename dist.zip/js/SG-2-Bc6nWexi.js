const p="/jpg/SG-2-DAPk19F9.jpg";export{p as _};
