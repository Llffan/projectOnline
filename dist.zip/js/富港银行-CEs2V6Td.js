const p="/png/%E5%AF%8C%E6%B8%AF%E9%93%B6%E8%A1%8C-CKGSdPI0.png";export{p as _};
