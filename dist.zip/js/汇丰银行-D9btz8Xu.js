const p="/png/%E6%B1%87%E4%B8%B0%E9%93%B6%E8%A1%8C-Div4M98_.png";export{p as _};
