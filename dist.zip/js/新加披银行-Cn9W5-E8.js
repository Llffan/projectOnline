const A="/png/%E6%96%B0%E5%8A%A0%E6%8A%AB%E9%93%B6%E8%A1%8C-ynLmxcOT.png";export{A as _};
