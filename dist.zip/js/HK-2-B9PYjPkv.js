const p="/jpg/HK-2-7MIX5Qvf.jpg";export{p as _};
