const p="/jpg/KY-ByCm0dxy.jpg",s="/jpg/KY-2-Brs8nAGJ.jpg";export{p as _,s as a};
