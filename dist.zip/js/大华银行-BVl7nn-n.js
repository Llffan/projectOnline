const E="/png/%E5%A4%A7%E5%8D%8E%E9%93%B6%E8%A1%8C-BurYoZ8O.png";export{E as _};
