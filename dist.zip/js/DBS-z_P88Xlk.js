const p="/jpg/9-T2p7MURJ.jpg";export{p as _};
