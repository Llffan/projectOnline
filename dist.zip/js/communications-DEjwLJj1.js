const p="/jpg/4-D3IpNSrW.jpg";export{p as _};
