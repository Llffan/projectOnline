const p="/jpg/BVI-2-tEUAi2hU.jpg";export{p as _};
