const p="/png/%E5%9B%BD%E9%99%85%E9%93%B6%E8%A1%8C-45rL9jAK.png";export{p as _};
