const p="/jpg/FR-QO5e6oCE.jpg",o="/jpg/FR-2-BBqx8tDz.jpg";export{p as _,o as a};
