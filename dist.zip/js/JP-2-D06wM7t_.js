const p="/jpg/JP-2-BBvs_lm8.jpg";export{p as _};
