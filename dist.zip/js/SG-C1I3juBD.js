const p="/jpg/SG-Z-9X0s0a.jpg";export{p as _};
