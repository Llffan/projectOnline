const p="/jpg/ID-C-M9d7n1.jpg",o="/jpg/ID-2-Cz7K4owK.jpg";export{p as _,o as a};
