const p="/jpg/US-ChswYrjP.jpg";export{p as _};
