const p="/png/KR-D0bzZFDc.png",o="/jpg/KR-2-BGvdBmoX.jpg";export{p as _,o as a};
