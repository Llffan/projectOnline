const p="/jpg/UK-2-BNfFL6x5.jpg";export{p as _};
