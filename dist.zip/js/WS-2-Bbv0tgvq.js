const p="/jpg/WS-C3_vrlHV.jpg",s="/jpg/WS-2-CCeV0-Xd.jpg";export{p as _,s as a};
