const p="/jpg/1-DK5lBdh-.jpg",s="/jpg/2-oiU3Gu_n.jpg",o="/jpg/3-DubU3yD0.jpg",_="/jpg/4-DWcFaVIA.jpg";export{p as _,s as a,o as b,_ as c};
