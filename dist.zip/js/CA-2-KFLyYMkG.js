const p="/jpg/CA-Dgeuei3m.jpg",o="/jpg/CA-2-CeyfoRef.jpg";export{p as _,o as a};
