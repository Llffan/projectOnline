const A="/png/%E6%91%A9%E6%A0%B9%E5%A4%A7%E9%80%9A%E9%93%B6%E8%A1%8C-DWtV4I1j.png";export{A as _};
