const p="/png/%E7%AB%8B%E6%A1%A5%E9%93%B6%E8%A1%8C-DJ9Z3y5Z.png";export{p as _};
