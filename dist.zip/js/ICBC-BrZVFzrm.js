const p="/jpg/ICBC-CMWZqmdm.jpg";export{p as _};
