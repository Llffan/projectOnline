const n="/png/patent_banner-D9xL_spz.png";export{n as _};
