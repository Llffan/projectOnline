const p="/jpg/JP-BftLP4hk.jpg";export{p as _};
