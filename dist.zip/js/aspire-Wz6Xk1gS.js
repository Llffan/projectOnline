const p="/png/aspire-DCAjvy-T.png";export{p as _};
