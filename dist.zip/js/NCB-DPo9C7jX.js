const p="/jpg/NCB-CLtSObxQ.jpg";export{p as _};
