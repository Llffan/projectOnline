const p="/jpg/HK-CPN4yL6e.jpg";export{p as _};
