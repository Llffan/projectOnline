const p="/png/%E5%B7%A5%E5%95%86%E9%93%B6%E8%A1%8C-UnopMbVi.png";export{p as _};
