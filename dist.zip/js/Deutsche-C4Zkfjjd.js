const n="/png/Deutsche-vxV2In7A.png";export{n as _};
