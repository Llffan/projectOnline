const s="/png/axos-ZWDQvYOs.png";export{s as _};
