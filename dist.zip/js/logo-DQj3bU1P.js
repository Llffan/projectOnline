const o="/png/logo-FJ3iIeDY.png";export{o as _};
