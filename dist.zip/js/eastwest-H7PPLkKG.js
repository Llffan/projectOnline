const s="/jpg/eastwest-IzB-x7Fe.jpg";export{s as _};
