const p="/png/%E8%8A%B1%E6%97%97%E9%93%B6%E8%A1%8C-DTc3Z-uO.png";export{p as _};
