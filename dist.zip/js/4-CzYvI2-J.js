const p="/jpg/1-De1sXJKf.jpg",s="/jpg/2-Df7p8AmX.jpg",t="/jpg/3-DaWXcIB3.jpg",o="/jpg/4-DhHGm4qt.jpg";export{p as _,s as a,t as b,o as c};
