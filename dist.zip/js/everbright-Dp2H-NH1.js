const p="/jpg/2-D3n1if1O.jpg";export{p as _};
