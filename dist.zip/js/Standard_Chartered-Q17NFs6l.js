const r="/jpg/Standard_Chartered-CIzX6vQB.jpg";export{r as _};
