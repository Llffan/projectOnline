const n="/png/1-Buji-niq.png";export{n as _};
