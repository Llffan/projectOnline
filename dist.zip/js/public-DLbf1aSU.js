const p="/png/public-DwAwGPFO.png";export{p as _};
