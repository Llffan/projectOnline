const p="/jpg/7-Zv42m_Zk.jpg";export{p as _};
