const p="/jpg/8-bvOVakFO.jpg";export{p as _};
