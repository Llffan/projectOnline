const p="/jpg/MO-FoQybptO.jpg";export{p as _};
