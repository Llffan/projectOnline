const p="/jpg/VN-RQ9FxD0L.jpg",s="/jpg/VN-2-DshnBoF0.jpg";export{p as _,s as a};
