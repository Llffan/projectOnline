const p="/jpg/MH-Cbi7GYOt.jpg",s="/jpg/MH-2-B2KDCnpq.jpg";export{p as _,s as a};
