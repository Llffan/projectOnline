const p="/jpg/3-CZMiZLSg.jpg";export{p as _};
