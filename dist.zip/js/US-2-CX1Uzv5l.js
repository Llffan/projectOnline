const p="/jpg/US-2-B4uWMxFk.jpg";export{p as _};
