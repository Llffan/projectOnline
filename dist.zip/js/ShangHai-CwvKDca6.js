const n="/png/ShangHai-Bi1dsfn9.png";export{n as _};
