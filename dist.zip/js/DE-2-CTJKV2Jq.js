const p="/jpg/DE-Ca39bQI7.jpg",s="/jpg/DE-2-Bupc7UkF.jpg";export{p as _,s as a};
