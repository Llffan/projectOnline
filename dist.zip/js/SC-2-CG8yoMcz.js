const p="/jpg/SC-Bp1pYlVF.jpg",s="/jpg/SC-2-CtGyFWQs.jpg";export{p as _,s as a};
