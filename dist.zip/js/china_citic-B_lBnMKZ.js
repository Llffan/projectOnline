const p="/jpg/6-DZBTi8hy.jpg";export{p as _};
