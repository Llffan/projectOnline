const p="/jpg/%E9%A6%99%E6%B8%AF-XEvzPyFk.jpg";export{p as _};
