const B="/png/%E6%B1%87%E4%B8%B0%E9%93%B6%E8%A1%8C-BudcCW4e.png";export{B as _};
