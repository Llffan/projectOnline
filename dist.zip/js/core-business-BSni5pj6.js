const s="/jpg/core-business-GD0z4TVK.jpg";export{s as _};
