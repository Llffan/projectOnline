const A="/png/%E9%A9%AC%E6%9D%A5%E8%A5%BF%E4%BA%9A-wTTS1EhJ.png";export{A as _};
