const g="/jpg/hang_seng-BlVWU0wD.jpg";export{g as _};
