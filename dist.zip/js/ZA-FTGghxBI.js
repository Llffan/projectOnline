const p="/png/ZA-BseM0J62.png";export{p as _};
