const p="/png/%E4%B8%AD%E5%9B%BD%E9%93%B6%E8%A1%8C-COh8kVhx.png";export{p as _};
