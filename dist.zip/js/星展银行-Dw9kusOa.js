const p="/png/%E6%98%9F%E5%B1%95%E9%93%B6%E8%A1%8C-B4flKxg1.png";export{p as _};
