const p="/jpg/OCBC-DEtsQquz.jpg";export{p as _};
