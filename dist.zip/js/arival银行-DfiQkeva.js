const p="/png/arival%E9%93%B6%E8%A1%8C-BiPch83y.png";export{p as _};
