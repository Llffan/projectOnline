const p="/jpg/MO-2-BsOqqShh.jpg";export{p as _};
