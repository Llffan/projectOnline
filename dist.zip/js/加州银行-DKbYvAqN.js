const E="/png/%E5%8A%A0%E5%B7%9E%E9%93%B6%E8%A1%8C-wkgI8yKG.png";export{E as _};
