const j="/jpg/UOB-C0AW_jjO.jpg";export{j as _};
