const p="/png/%E6%B0%B4%E6%98%9F%E9%93%B6%E8%A1%8C-BbuANkqy.png";export{p as _};
